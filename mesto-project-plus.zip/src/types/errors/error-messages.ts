export const SERVER_ERROR_MESSAGE = "Ошибка сервера.";
export const BAD_REQUEST_MESSAGE = "Переданы некорректные данные.";
export const INVALID_ID_MESSAGE = 'Передан невалидный _id.'
export const NOT_FOUND_MESSAGE = 'По данному запросу ничего не найдено.'
export const USER_NOT_FOUND = "Пользователь с указанным _id не найден.";
export const CARD_NOT_FOUND = "Карточка с указанным _id не найдена.";